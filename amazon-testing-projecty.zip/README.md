# Amazon Testing Project

This is a test automation project for Amazon.