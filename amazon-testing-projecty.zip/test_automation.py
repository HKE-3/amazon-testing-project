import unittest

class AmazonTest(unittest.TestCase):
    def test_sample(self):
        self.assertEqual(1, 1)

if __name__ == '__main__':
    unittest.main()
    